cd /root/code/ga/ga_cvrp_test_Chong_noSaing/
nohup python cvrp_runner.py > ../ga_cvrp_test_Chong_noSaing.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_Chong_noSaing2/
nohup python cvrp_runner.py > ../ga_cvrp_test_Chong_noSaing2.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_Chong_Saing/
nohup python cvrp_runner.py > ../ga_cvrp_test_Chong_Saing.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_Chong_Saing2/
nohup python cvrp_runner.py > ../ga_cvrp_test_Chong_Saing2.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_noChong_noSaing/
nohup python cvrp_runner.py > ../ga_cvrp_test_noChong_noSaing.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_noChong_noSaing2/
nohup python cvrp_runner.py > ../ga_cvrp_test_noChong_noSaing2.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_noChong_Saing/
nohup python cvrp_runner.py > ../ga_cvrp_test_noChong_Saing.log 2>&1 &

cd /root/code/ga/ga_cvrp_test_noChong_Saing2/
nohup python cvrp_runner.py > ../ga_cvrp_test_noChong_Saing2.log 2>&1 &
